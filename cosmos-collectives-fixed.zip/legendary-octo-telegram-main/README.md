test website:
v0.1
- html static website
- home page, products page, about and contact page, reviews page, faq page

v0.2
- animated images ( reactbits)
- new images
-text on animated images

v0.3
- placeholder

v0.3.1 - code cleanup
- shared css/base.css (colour variables, nav, banner, tables) + one small stylesheet per page
- all HTML cleaned: no deprecated tags (font, center, align, bgcolor), semantic markup, mobile friendly
- homepage astronaut photos now sit side by side
- files organised into css/, js/ and images/ folders; pages renamed (index, products, about, reviews, faq, checkout)

Project structure (inside "html 2026")
- index.html, products.html, about.html, reviews.html, faq.html, checkout.html
- css/        base.css + per-page css, css/components/ (animated component styles)
- js/         js/components/ (animated components - unchanged)
- images/     home/, products/, pages/, _duplicates/ (identical copies, not used)


v0.3.2 - fixes + content
- root index.html forwards to "html 2026/index.html" (the homepage was unreachable because the repo root had no index.html)
- all previously unused images now placed (Jupiter astronaut + fan favourites + Earth delivery banner on home, slogan card on about)
- HTML + CSS only; ReactBits JS untouched
